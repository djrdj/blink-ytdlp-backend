from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import yt_dlp
import os
import tempfile
import requests
from typing import Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Blink Video Extraction Service")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ExtractionRequest(BaseModel):
    url: str
    supabase_url: str
    supabase_key: str

class ExtractionResponse(BaseModel):
    success: bool
    video_path: Optional[str] = None
    thumbnail_path: Optional[str] = None
    metadata: dict = {}
    error: Optional[str] = None

@app.get("/")
async def root():
    return {"status": "Blink yt-dlp extraction service running", "version": "1.0"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post("/extract", response_model=ExtractionResponse)
async def extract_video(request: ExtractionRequest):
    """
    Extract video from social media URL using yt-dlp
    Downloads video and uploads to Supabase Storage
    """
    try:
        logger.info(f"Extracting video from: {request.url}")
        
        # Create temporary directory for downloads
        with tempfile.TemporaryDirectory() as temp_dir:
            video_path = os.path.join(temp_dir, 'video.%(ext)s')
            
            # yt-dlp options
            ydl_opts = {
                'format': 'best[ext=mp4]/best',  # Prefer MP4 format
                'outtmpl': video_path,
                'quiet': False,
                'no_warnings': False,
                'extract_flat': False,
                'nocheckcertificate': True,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Sec-Fetch-Mode': 'navigate',
                },
                'writethumbnail': True,  # Download thumbnail
                'writesubtitles': False,
            }
            
            # Extract video info and download
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                logger.info("Extracting video info...")
                info = ydl.extract_info(request.url, download=True)
                
                # Get metadata
                metadata = {
                    'title': info.get('title', 'Video'),
                    'description': info.get('description', ''),
                    'author': info.get('uploader', '') or info.get('channel', ''),
                    'duration': info.get('duration', 0),
                    'platform': info.get('extractor_key', 'unknown').lower(),
                    'thumbnail_url': info.get('thumbnail', ''),
                    'upload_date': info.get('upload_date', ''),
                    'view_count': info.get('view_count', 0),
                }
                
                logger.info(f"Video info extracted: {metadata['title']}")
                
                # Find downloaded video file
                video_file = None
                thumbnail_file = None
                
                for file in os.listdir(temp_dir):
                    file_path = os.path.join(temp_dir, file)
                    if file.endswith(('.mp4', '.webm', '.mkv')) and os.path.isfile(file_path):
                        video_file = file_path
                        logger.info(f"Found video file: {file} ({os.path.getsize(file_path)} bytes)")
                    elif file.endswith(('.jpg', '.jpeg', '.png', '.webp')) and os.path.isfile(file_path):
                        thumbnail_file = file_path
                        logger.info(f"Found thumbnail: {file} ({os.path.getsize(file_path)} bytes)")
                
                if not video_file:
                    raise Exception("Video file not found after download")
                
                # Upload video to Supabase Storage
                logger.info("Uploading video to Supabase Storage...")
                video_storage_path = await upload_to_supabase(
                    video_file,
                    f"video_{os.urandom(8).hex()}.mp4",
                    "video/mp4",
                    request.supabase_url,
                    request.supabase_key
                )
                
                # Upload thumbnail if available
                thumbnail_storage_path = None
                if thumbnail_file:
                    logger.info("Uploading thumbnail to Supabase Storage...")
                    thumbnail_storage_path = await upload_to_supabase(
                        thumbnail_file,
                        f"thumb_{os.urandom(8).hex()}.jpg",
                        "image/jpeg",
                        request.supabase_url,
                        request.supabase_key
                    )
                
                logger.info(f"Upload complete - video: {video_storage_path}, thumbnail: {thumbnail_storage_path}")
                
                return ExtractionResponse(
                    success=True,
                    video_path=video_storage_path,
                    thumbnail_path=thumbnail_storage_path,
                    metadata=metadata
                )
                
    except Exception as e:
        logger.error(f"Extraction failed: {str(e)}")
        return ExtractionResponse(
            success=False,
            error=str(e)
        )

async def upload_to_supabase(file_path: str, storage_filename: str, content_type: str, supabase_url: str, supabase_key: str) -> str:
    """
    Upload file to Supabase Storage bucket
    """
    try:
        with open(file_path, 'rb') as f:
            file_data = f.read()
        
        upload_url = f"{supabase_url}/storage/v1/object/blink-videos/{storage_filename}"
        
        headers = {
            'Authorization': f'Bearer {supabase_key}',
            'Content-Type': content_type,
            'x-upsert': 'true'
        }
        
        response = requests.post(upload_url, headers=headers, data=file_data)
        
        if response.status_code not in [200, 201]:
            raise Exception(f"Upload failed: {response.status_code} - {response.text}")
        
        logger.info(f"Uploaded {storage_filename} ({len(file_data)} bytes)")
        return storage_filename
        
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        raise

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
